module.exports = {
  lintOnSave: false,
  devServer: {
    disableHostCheck: true
  }
}
