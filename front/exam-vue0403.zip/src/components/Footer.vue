<template>
  <el-footer>
    <span>&copy;2023-2023 Power By XXX</span>
    <br>
    <i class="el-icon-thumb"></i>
  </el-footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>

</style>
