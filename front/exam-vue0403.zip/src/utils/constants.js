export default {
  defaultExamName: '<该考试不存在>'
}
